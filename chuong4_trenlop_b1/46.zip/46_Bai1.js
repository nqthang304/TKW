let a = 10;
let b = 20;

if (a < b) {
    console.log(a+" nho hon "+b);
}
else if (a > b) {
    console.log(a+" lon hon "+b);
}
else {
    console.log(a+" bang "+b);
}