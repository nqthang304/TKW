let number = -5;
if (number > 0) {
    console.log(number + " la so duong");
}
else if (number < 0) {
    console.log(number + " la so am");
}
else {
    console.log(number + " la so 0");
}