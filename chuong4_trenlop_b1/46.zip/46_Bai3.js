let score = 72;

if (score >= 85) {
    console.log("Xep loai: A");
}
else if (score >= 70) {
    console.log("Xep loai: B");
}
else if (score >= 50) {
    console.log("Xep loai: C");
}
else {
    console.log("Xep loai: D");
}