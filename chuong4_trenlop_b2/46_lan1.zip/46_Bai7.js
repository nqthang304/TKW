let A =  [3, 5, 7, 2, 8, 1, 4]
let SLN = A[0]
for (let i in A) {
    if (A[i] > SLN) {
        SLN = A[i]
    }
}
console.log(SLN)