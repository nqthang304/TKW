let A =[1, 3, 5, 3, 7, 9, 3, 1, 3]
let dem=0
for (let i in A) {
    if (A[i] === 3) {
        dem++;
    }
}
console.log(dem)