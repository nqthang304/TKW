let dem = 0
for (let i = 1; i < 51; i++) {
    if (i % 2 === 0) {
        dem++;
    }
}
console.log(dem)