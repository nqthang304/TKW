let A=[1, 2, 3, 4, 5, 6, 7, 8, 9]
let sum_le=0
for (let i of A) {
    if (i % 2 !== 0) {
        sum_le+=i
    }
}
console.log(sum_le)