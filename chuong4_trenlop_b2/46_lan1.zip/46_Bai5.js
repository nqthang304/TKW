let A =  ["apple", "banana", "orange", "mango"]
for (let i in A) {
    console.log(A[i])
}