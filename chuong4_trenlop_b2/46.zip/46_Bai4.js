
inKQ = (n) => {
    console.log(n)
}

inSo = () => {
    for (let i = 1; i<=10; i++) {
        inKQ(i)
    }
}

inSo()